
<?php $__env->startSection('content'); ?>

<main class="site-content" id="content">
      <!-- START: Breadcrumb Area -->
      <section class="breadcrumb_area" data-bg-image="./assets/img/breadcrumb/breadcrumb-bg.jpg"
         data-bg-color="#140C1C">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="breadcrumb_content d-flex flex-column align-items-center">
                     <h2 class="title wow fadeInUp" data-wow-delay=".3s">About Us</h2>
                     <div class="breadcrumb_navigation wow fadeInUp" data-wow-delay=".5s">
                        <span><a href="index.html">Home</a></span>
                        <i class="far fa-long-arrow-right"></i>
                        <span class="current-item">About Us</span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- END: Breadcrumb Area -->

      <!-- start: Works Area -->
      <section class="works-section style-2" id="resume-section">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="section-header text-center">
                     <h2 class="section-title wow fadeInUp" data-wow-delay=".3s">My Resume</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-12">
                  <div class="works-wrapper">
                     <!-- Education Section -->
                     <div class="works-content-item">
                        <h3 class="title wow fadeInLeft" data-wow-delay=".3s">Education</h3>
                        <div class="works-inner wow fadeInUp" data-wow-delay=".4s">
                           <div class="works-item">
                              <div class="works-icon">
                                 <i class="flaticon-graduation-cap"></i>
                              </div>
                              <div class="works-content">
                                 <span class="number">2023 - CONTINUE BSCS Final Year </span>
                                 <h5 class="title">Bachelor of Computer Science</h5>
                                 <span class="sub-title">NCBA</span>
                              </div>
                           </div>
                           <div class="works-item">
                              <div class="works-icon">
                                 <i class="flaticon-graduation-cap"></i>
                              </div>
                              <div class="works-content">
                                 <span class="number">2021 - 2023</span>
                                 <h5 class="title">BACHELOR</h5>
                                 <span class="sub-title">ADP CS ( Associate degree program in computer science) from
                                 ucp( University Of Central Punjab)</span>
                              </div>
                           </div>
                           <div class="works-item">
                              <div class="works-icon">
                                 <i class="flaticon-graduation-cap"></i>
                              </div>
                              <div class="works-content">
                                 <span class="number">2021</span>
                                 <h5 class="title">INTERMEDIATE</h5>
                                 <span class="sub-title">FA from superior collage</span>
                              </div>
                           </div>
                           <div class="works-item">
                              <div class="works-icon">
                                 <i class="flaticon-graduation-cap"></i>
                              </div>
                              <div class="works-content">
                                 <span class="number">2018</span>
                                 <h5 class="title">BISE Lahore </h5>
                                 <span class="sub-title">Matric</span>
                              </div>
                           </div>
                        </div>
                     </div>

                     <!-- Work Experience Section -->
                     <div class="works-content-item">
                        <h3 class="title wow fadeInRight" data-wow-delay=".3s">Work Experience</h3>
                        <div class="works-inner wow fadeInUp" data-wow-delay=".4s">
                           <div class="works-item">
                              <div class="works-icon">
                                 <i class="flaticon-suitcase"></i>
                              </div>
                              <div class="works-content">
                                 <span class="number">2023 - CONTINUE At BMGROUP,LAHORE</span>
                                 <h5 class="title">Laravel Developer</h5>
                                 <span class="sub-title">& WordPress</span>
                              </div>
                           </div>
                           <div class="works-item">
                              <div class="works-icon">
                                 <i class="flaticon-suitcase"></i>
                              </div>
                              <div class="works-content">
                                 <span class="number">2021 - 2023</span>
                                 <h5 class="title">Front-End Developer</h5>
                                 <span class="sub-title">MAXFLAPTECHNOLOGIES,LAHORE (2023-2024)</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- end: Works Area -->



      <!-- start: Skills Area -->
      <section class="skills-section style-3" id="skills-section">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="section-header text-center">
                     <h2 class="section-title wow fadeInUp" data-wow-delay=".3s">My Skills</h2>
                     <p class="text-uppercase wow fadeInUp" data-wow-delay=".4s">
                        What I Offer
                     </p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <div class="skills-widget d-flex flex-wrap justify-content-center align-items-center">
                     <div class="skill-item wow fadeInUp" data-wow-delay=".3s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/html.svg" alt="HTML Icon" />
                           </div>
                           <div class="number">95%</div>
                        </div>
                        <p>HTML</p>
                     </div>
                     <div class="skill-item wow fadeInUp" data-wow-delay=".4s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/css.svg" alt="CSS Icon" />
                           </div>
                           <div class="number">90%</div>
                        </div>
                        <p>CSS</p>
                     </div>
                     <div class="skill-item wow fadeInUp" data-wow-delay=".5s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/bootstrap.svg" alt="Bootstrap Icon" />
                           </div>
                           <div class="number">85%</div>
                        </div>
                        <p>Bootstrap</p>
                     </div>
                     <div class="skill-item wow fadeInUp" data-wow-delay=".7s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/laravel.svg" alt="Laravel Icon" />
                           </div>
                           <div class="number">88%</div>
                        </div>
                        <p>Laravel</p>
                     </div>
                     <div class="skill-item wow fadeInUp" data-wow-delay=".8s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/js.svg" alt="JavaScript Icon" />
                           </div>
                           <div class="number">93%</div>
                        </div>
                        <p>JavaScript</p>
                     </div>
                     <div class="skill-item wow fadeInUp" data-wow-delay="1s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/git.svg" alt="Git Icon" />
                           </div>
                           <div class="number">85%</div>
                        </div>
                        <p>Git</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- end: Skills Area -->


      <!-- start: Counter Area -->
      <!-- start: Counter Area -->
      <section class="counter-section">
         <div class="container">
            <div class="row">
               <div class="col-12">
                  <div class="funfact-area">
                     <div class="row">
                        <div class="col-6 col-lg-3">
                           <div
                              class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center wow fadeInUp"
                              data-wow-delay=".3s">
                              <div class="number"><span class="odometer" data-count="10">0</span>+</div>
                              <div class="text">Years of <br />Experience</div>
                           </div>
                        </div>
                        <div class="col-6 col-lg-3">
                           <div
                              class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center wow fadeInUp"
                              data-wow-delay=".4s">
                              <div class="number"><span class="odometer" data-count="75">0</span>+</div>
                              <div class="text">Projects <br />Completed</div>
                           </div>
                        </div>
                        <div class="col-6 col-lg-3">
                           <div
                              class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center wow fadeInUp"
                              data-wow-delay=".5s">
                              <div class="number"><span class="odometer" data-count="200">0</span>+</div>
                              <div class="text">Happy <br />Clients</div>
                           </div>
                        </div>
                        <div class="col-6 col-lg-3">
                           <div
                              class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center wow fadeInUp"
                              data-wow-delay=".6s">
                              <div class="number"><span class="odometer" data-count="15">0</span></div>
                              <div class="text">Awards <br />Won</div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- end: Counter Area -->

      <!-- start: Text Area -->
      <section class="text-section">
         <div class="container">
            <div class="row">
               <div class="col-12">
                  <div class="section-header d-flex flex-wrap align-items-center justify-content-between">
                     <div class="heading-left">
                        <p class="wow fadeInUp" data-wow-delay=".3s">Ready to bring your ideas to life?</p>
                        <h2 id="anim" class="section-title wow fadeInUp" data-wow-delay=".4s">Let’s Collaborate!</h2>
                     </div>
                     <div class="chat-mail wow fadeInRight" data-wow-delay=".5s">
                        <a class="link" href="mailto:contact@yourdomain.com">
                           contact@yourdomain.com <i class="fa-light fa-arrow-right"></i>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- end: Text Area -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\portfolio\resources\views/about-us.blade.php ENDPATH**/ ?>