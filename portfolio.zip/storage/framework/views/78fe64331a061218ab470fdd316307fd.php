

<?php $__env->startSection('content'); ?>

   <main class="site-content" id="content">
      <!-- HERO SECTION START -->
      <section class="hero-section d-flex align-items-center" id="intro">
         <div class="intro_text">
            <svg viewBox="0 0 1320 300">
               <text x="50%" Y="50%" text-anchor="middle">HI</text>
            </svg>
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-md-6">
                  <div class="hero-content-box">
                     <span class="hero-sub-title"></span>
                     <h1 class="hero-title"> I am a Front-End Developer</h1>

                     <div class="hero-image-box d-md-none text-center">
                        <img src="assets/img/hero/me.png" alt="Front-End Developer" />
                     </div>

                     <p class="lead">
                        I am a passionate web developer with 2 years of experience in building modern and responsive websites using HTML, CSS, JavaScript, and popular frameworks like Bootstrap, Laravel, and WordPress. Let's create seamless user experiences!
                     </p>
                     <div class="button-box d-flex flex-wrap align-items-center">
                        <a href="assets\img\abrar-cv.pdf" class="btn tj-btn-secondary">Download CV <i class="flaticon-download"></i></a>
                        <ul class="ul-reset social-icons">
                           <li>
                              <a href="https://twitter.com/yourusername" target="_blank"><i class="fa-brands fa-twitter"></i></a>
                           </li>
                           <li>
                              <a href="https://github.com/yourusername" target="_blank"><i class="fa-brands fa-github"></i></a>
                           </li>
                           <li>
                              <a href="https://www.linkedin.com/in/abrar-amjad-87450a288/" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-md-6 d-none d-md-block">
                  <div class="hero-image-box text-center">
                     <img src="assets/img/hero/me.png" alt="Front-End Developer" />
                  </div>
               </div>
            </div>
            <div class="funfact-area">
               <div class="row">
                  <div class="col-6 col-lg-3">
                     <div class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center">
                        <div class="number"><span class="odometer" data-count="2">0</span></div>
                        <div class="text">Years of <br />Experience</div>
                     </div>
                  </div>
                  <div class="col-6 col-lg-3">
                     <div class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center">
                        <div class="number"><span class="odometer" data-count="25">0</span>+</div>
                        <div class="text">Projects <br />Completed</div>
                     </div>
                  </div>
                  <div class="col-6 col-lg-3">
                     <div class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center">
                        <div class="number"><span class="odometer" data-count="50">0</span>+</div>
                        <div class="text">Happy <br />Clients</div>
                     </div>
                  </div>
                  <div class="col-6 col-lg-3">
                     <div class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center">
                        <div class="number"><span class="odometer" data-count="6">0</span>+</div>
                        <div class="text">Technologies <br />Used</div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- HERO SECTION END -->


      <!-- SERVICES SECTION START -->
      <section class="services-section" id="services-section">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="section-header text-center">
                     <h2 class="section-title wow fadeInUp" data-wow-delay=".3s">My Quality Services</h2>
                     <p class="wow fadeInUp" data-wow-delay=".4s">
                        I offer top-tier web development services using the latest technologies. My goal is to create responsive, user-friendly, and performance-focused websites that help your business grow.
                     </p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <div class="services-widget position-relative">
                     <!-- Service 1: Responsive Design -->
                     <div class="service-item current d-flex flex-wrap align-items-center wow fadeInUp" data-wow-delay=".5s">
                        <div class="left-box d-flex flex-wrap align-items-center">
                           <span class="number">01</span>
                           <h3 class="service-title">Responsive Design</h3>
                        </div>
                        <div class="right-box">
                           <p>
                              I ensure your website is fully responsive, making it look great on all devices and screen sizes. Whether it’s a desktop, tablet, or mobile phone, your users will have a seamless experience.
                           </p>
                        </div>
                        <i class="flaticon-up-right-arrow"></i>
                        <button data-mfp-src="#service-wrapper" class="service-link modal-popup"></button>
                     </div>
                     <!-- Service 2: CMS Development -->
                     <div class="service-item d-flex flex-wrap align-items-center wow fadeInUp" data-wow-delay=".6s">
                        <div class="left-box d-flex flex-wrap align-items-center">
                           <span class="number">02</span>
                           <h3 class="service-title">CMS Development</h3>
                        </div>
                        <div class="right-box">
                           <p>
                              I specialize in building and customizing CMS solutions like WordPress, allowing you to easily manage and update your website’s content without needing technical skills.
                           </p>
                        </div>
                        <i class="flaticon-up-right-arrow"></i>
                        <button data-mfp-src="#service-wrapper" class="service-link modal-popup"></button>
                     </div>
                     <!-- Service 3: API Integrations -->
                     <div class="service-item d-flex flex-wrap align-items-center wow fadeInUp" data-wow-delay=".7s">
                        <div class="left-box d-flex flex-wrap align-items-center">
                           <span class="number">03</span>
                           <h3 class="service-title">API Integrations</h3>
                        </div>
                        <div class="right-box">
                           <p>
                              I integrate APIs to extend your website’s functionality. From payment gateways to social media integrations, I can connect your website with third-party services for better user experience.
                           </p>
                        </div>
                        <i class="flaticon-up-right-arrow"></i>
                        <button data-mfp-src="#service-wrapper" class="service-link modal-popup"></button>
                     </div>
                     <!-- Service 4: Website Redesign -->
                     <div class="service-item d-flex flex-wrap align-items-center wow fadeInUp" data-wow-delay=".8s">
                        <div class="left-box d-flex flex-wrap align-items-center">
                           <span class="number">04</span>
                           <h3 class="service-title">Website Redesign</h3>
                        </div>
                        <div class="right-box">
                           <p>
                              I help businesses modernize their outdated websites with fresh, engaging designs that are aligned with current trends and your brand's goals, while ensuring better user experience and performance.
                           </p>
                        </div>
                        <i class="flaticon-up-right-arrow"></i>
                        <button data-mfp-src="#service-wrapper" class="service-link modal-popup"></button>
                     </div>
                     <div class="active-bg wow fadeInUp" data-wow-delay=".5s"></div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- SERVICES SECTION END -->


      <!-- start: Service Popup -->
      <div id="service-wrapper" class="popup_content_area zoom-anim-dialog mfp-hide" data-lenis-prevent>
         <div class="popup_modal_img">
            <img src="./assets/img/services/modal-img.jpg" alt="Service Image" />
         </div>
         <div class="popup_modal_content">
            <div class="service_details">
               <div class="row">
                  <div class="col-lg-7 col-xl-8">
                     <div class="service_details_content">
                        <div class="service_info">
                           <h6 class="subtitle">SERVICES</h6>
                           <h2 class="title">Responsive Web Design</h2>
                           <div class="desc">
                              <p>
                                 Our responsive web design ensures that your website looks amazing on all devices, adapting seamlessly to any screen size or resolution.
                              </p>
                              <p>
                                 Whether it's a smartphone, tablet, or desktop, we ensure your website is optimized for the best user experience across all platforms.
                              </p>
                              <p>
                                 With our expertise in designing mobile-first websites, we guarantee that every page is fully optimized for any device or browser.
                              </p>
                           </div>

                           <h3 class="title">Our Process</h3>
                           <div class="desc">
                              <p>
                                 We follow a clear and structured approach to ensure your website exceeds expectations and delivers a seamless user experience:
                              </p>
                           </div>
                           <ul>
                              <li>In-depth Consultation to Understand Your Needs</li>
                              <li>Wireframing and Prototyping for Clear Vision</li>
                              <li>Design Development with Responsive Layouts</li>
                              <li>Quality Testing Across Multiple Devices</li>
                              <li>Final Adjustments and Go Live</li>
                              <li>Ongoing Support and Maintenance</li>
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-5 col-xl-4">
                     <div class="tj_main_sidebar">
                        <div class="sidebar_widget services_list">
                           <div class="widget_title">
                              <h3 class="title">All Services</h3>
                           </div>
                           <ul>
                              <li class="active">
                                 <button>
                                    <i class="flaticon-design"></i>
                                    Branding Design
                                 </button>
                              </li>
                              <li>
                                 <button>
                                    <i class="flaticon-3d-movie"></i>
                                    3D Animation
                                 </button>
                              </li>
                              <li>
                                 <button>
                                    <i class="flaticon-ux-design"></i>
                                    UI/UX Design
                                 </button>
                              </li>
                              <li>
                                 <button>
                                    <i class="flaticon-web-design"></i>
                                    Web Design
                                 </button>
                              </li>
                              <li>
                                 <button>
                                    <i class="flaticon-ui-design"></i>
                                    App Design
                                 </button>
                              </li>
                           </ul>
                        </div>

                        <div class="sidebar_widget contact_form">
                           <div class="widget_title">
                              <h3 class="title">Get in Touch</h3>
                           </div>

                           <form action="index.html">
                              <div class="form_group">
                                 <input type="text" name="name" id="name" placeholder="Name" autocomplete="off" />
                              </div>
                              <div class="form_group">
                                 <input type="email" name="semail" id="semail" placeholder="Email" autocomplete="off" />
                              </div>
                              <div class="form_group">
                                 <textarea name="smessage" id="smessage" placeholder="Your message" autocomplete="off"></textarea>
                              </div>
                              <div class="form_btn">
                                 <button class="btn tj-btn-primary" type="submit">Send Message</button>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end: Service Popup -->



      <!-- PORTFOLIO SECTION START -->
      <section class="portfolio-section" id="works-section">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="section-header text-center">
                     <h2 class="section-title wow fadeInUp" data-wow-delay=".3s">My Recent Works</h2>
                     <p class="wow fadeInUp" data-wow-delay=".4s">
                        Bringing your vision to life through a perfect blend of HTML, CSS, Bootstrap, JavaScript, Laravel, and WordPress.
                     </p>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-12">
                  <div class="portfolio-filter text-center wow fadeInUp" data-wow-delay=".5s">
                     <div class="button-group filter-button-group">
                        <button data-filter="*" class="active">All</button>
                        <button data-filter=".uxui">UX/UI</button>
                        <button data-filter=".branding">Branding</button>
                        <button data-filter=".mobile-app">Apps</button>
                        <div class="active-bg"></div>
                     </div>
                  </div>

                  <div class="portfolio-box wow fadeInUp" data-wow-delay=".6s">
                     <div class="portfolio-sizer"></div>
                     <div class="gutter-sizer"></div>

                     <!-- Branding Project -->
                     <div class="portfolio-item branding">
                        <div class="image-box">
                           <img src="assets/img/portfolio/2.jpg" alt="Branding Project" />
                        </div>
                        <div class="content-box">
                           <h3 class="portfolio-title">Deloitte Branding</h3>
                           <p>Created a professional and innovative branding strategy for Deloitte, focusing on precision and trust for their global audience.</p>
                           <p>Technologies Used: HTML, CSS, Bootstrap, JavaScript</p>
                           <i class="flaticon-up-right-arrow"></i>
                           <button data-mfp-src="#portfolio-wrapper" class="portfolio-link modal-popup"></button>
                        </div>
                     </div>

                     <!-- UX/UI Project -->
                     <div class="portfolio-item uxui">
                        <div class="image-box">
                           <img src="assets/img/portfolio/1.jpg" alt="UX/UI Design Project" />
                        </div>
                        <div class="content-box">
                           <h3 class="portfolio-title">New Age Web Design</h3>
                           <p>Designed a user-friendly and responsive website for New Age, optimizing UX/UI for easy navigation and customer satisfaction.</p>
                           <p>Technologies Used: HTML, CSS, Bootstrap, JavaScript, WordPress</p>
                           <i class="flaticon-up-right-arrow"></i>
                           <button data-mfp-src="#portfolio-wrapper" class="portfolio-link modal-popup"></button>
                        </div>
                     </div>

                     <!-- Mobile App Project -->
                     <div class="portfolio-item mobile-app">
                        <div class="image-box">
                           <img src="assets/img/portfolio/3.jpg" alt="Mobile App Project" />
                        </div>
                        <div class="content-box">
                           <h3 class="portfolio-title">Sebastian App</h3>
                           <p>Developed a highly interactive mobile app for Sebastian to streamline services and enhance user engagement.</p>
                           <p>Technologies Used: HTML, CSS, JavaScript, Laravel, WordPress</p>
                           <i class="flaticon-up-right-arrow"></i>
                           <button data-mfp-src="#portfolio-wrapper" class="portfolio-link modal-popup"></button>
                        </div>
                     </div>

                     <!-- Branding Project -->
                     <div class="portfolio-item branding">
                        <div class="image-box">
                           <img src="assets/img/portfolio/4.jpg" alt="Branding Project" />
                        </div>
                        <div class="content-box">
                           <h3 class="portfolio-title">Mochnix Logo Design</h3>
                           <p>Created a fresh and dynamic logo for Mochnix, representing their tech-forward vision and innovative approach.</p>
                           <p>Technologies Used: HTML, CSS, Bootstrap</p>
                           <i class="flaticon-up-right-arrow"></i>
                           <button data-mfp-src="#portfolio-wrapper" class="portfolio-link modal-popup"></button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- PORTFOLIO SECTION END -->


      <!-- start: Portfolio Popup -->
      <div id="portfolio-wrapper" class="popup_content_area zoom-anim-dialog mfp-hide" data-lenis-prevent>
         <div class="popup_modal_img">
            <img src="./assets/img/portfolio/modal-img.jpg" alt="Portfolio Image" />
         </div>
         <div class="popup_modal_content">
            <div class="portfolio_info">
               <div class="portfolio_info_text">
                  <h2 class="title">DStudio</h2>
                  <div class="desc">
                     <p>
                        They are was greater open above shelter lets itself under appear sixth open gathering made upon
                        can't own above midst gathering gathered he one us saying can't divide.
                     </p>
                  </div>
                  <a href="#" class="btn tj-btn-primary">live preview <i class="fal fa-arrow-right"></i></a>
               </div>
               <div class="portfolio_info_items">
                  <div class="info_item">
                     <div class="key">Category</div>
                     <div class="value">Web Design</div>
                  </div>
                  <div class="info_item">
                     <div class="key">Client</div>
                     <div class="value">Artboard Studio</div>
                  </div>
                  <div class="info_item">
                     <div class="key">Start Date</div>
                     <div class="value">August 20, 2023</div>
                  </div>
                  <div class="info_item">
                     <div class="key">Designer</div>
                     <div class="value"><a href="#">ThemeJunction</a></div>
                  </div>
               </div>
            </div>
            <div class="portfolio_gallery owl-carousel">
               <div class="gallery_item">
                  <img src="./assets/img/portfolio-gallery/p-gallery-1.jpg" alt="Gallery Image 1" />
               </div>
               <div class="gallery_item">
                  <img src="./assets/img/portfolio-gallery/p-gallery-2.jpg" alt="Gallery Image 2" />
               </div>
               <div class="gallery_item">
                  <img src="./assets/img/portfolio-gallery/p-gallery-3.jpg" alt="Gallery Image 3" />
               </div>
               <div class="gallery_item">
                  <img src="./assets/img/portfolio-gallery/p-gallery-4.jpg" alt="Gallery Image 4" />
               </div>
            </div>
            <div class="portfolio_description">
               <h2 class="title">Project Description</h2>
               <div class="desc">
                  <p>
                     The goal is there are many variations of passages of Lorem Ipsum available, but the majority have
                     suffered alteration in some
                     form, by injected humour, or randomised words which don't look even slightly believable.
                  </p>

                  <p>
                     There are many variations of passages of Lorem Ipsum available, but the majority have suffered
                     alteration in some form, by
                     injected humour, or randomised words which don't look even slightly believable. If you are going to
                     use a passage of Lorem
                     Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.
                  </p>
               </div>
            </div>
            <div class="portfolio_story_approach">
               <div class="portfolio_story">
                  <div class="story_title">
                     <h4 class="title">The story</h4>
                  </div>
                  <div class="story_content">
                     <p>
                        There are many variations of passages of Lorem Ipsum available, but the majority have suffered
                        alteration in some form, by
                        injected humour, or randomised words which don't look even slightly believable. If you are going
                        to use a passage of Lorem
                        Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. There
                        are many variations of
                        passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by
                        injected humour, or
                        randomised words which don't look even slightly believable. If you are going to use a passage of
                        Lorem Ipsum, you need to
                        be sure there isn't anything embarrassing hidden in the middle of text.
                     </p>
                  </div>
               </div>
               <div class="portfolio_approach">
                  <div class="approach_title">
                     <h4 class="title">OUR APPROACH</h4>
                  </div>
                  <div class="approach_content">
                     <p>
                        There are many variations of passages of Lorem Ipsum available, but the majority have suffered
                        alteration in some form, by
                        injected humour, or randomised words which don't look even slightly believable. If you are going
                        to use a passage of Lorem
                        Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. There
                        are many variations of
                        passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by
                        injected humour, or
                        randomised words which don't look even slightly believable. If you are going to use a passage of
                        Lorem Ipsum, you need to
                        be sure there isn't anything embarrassing hidden in the middle of text.
                     </p>
                  </div>
               </div>
            </div>
            <div class="portfolio_navigation">
               <div class="navigation_item prev-project">
                  <a href="#" class="project">
                     <i class="fal fa-arrow-left"></i>
                     <div class="nav_project">
                        <div class="label">Previous Project</div>
                        <h3 class="title">Sebastian</h3>
                     </div>
                  </a>
               </div>
               <div class="navigation_item next-project">
                  <a href="#" class="project">
                     <div class="nav_project">
                        <div class="label">Next Project</div>
                        <h3 class="title">Qwillo</h3>
                     </div>
                     <i class="fal fa-arrow-right"></i>
                  </a>
               </div>
            </div>
         </div>
      </div>
      <!-- end: Portfolio Popup -->


      <!-- RESUME SECTION START -->
      <section class="resume-section" id="resume-section">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
                  <div class="section-header wow fadeInUp" data-wow-delay=".3s">
                     <h2 class="section-title"><i class="flaticon-recommendation"></i> My Experience</h2>
                  </div>
                  <div class="resume-widget">
                     <div class="resume-item wow fadeInLeft" data-wow-delay=".4s">
                        <div class="time">2023 - Present</div>
                        <h3 class="resume-title">Frontend Web Developer</h3>
                        <div class="institute">BMGROUP, Lahore</div>
                        <p>As a frontend web developer, I design and develop user-friendly websites using HTML, CSS, and JavaScript. I collaborate with designers and back-end developers to implement UI features and ensure cross-browser compatibility and website performance optimization.</p>
                     </div>
                     <div class="resume-item wow fadeInLeft" data-wow-delay=".5s">
                        <div class="time">2023 - 2024</div>
                        <h3 class="resume-title">Frontend Web Developer</h3>
                        <div class="institute">MAXFLAP TECHNOLOGIES, Lahore</div>
                        <p>Designed and developed responsive websites, ensuring cross-browser compatibility and performance optimization. Collaborated with design and back-end teams for UI implementation and conducted code reviews to adhere to best practices.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="section-header wow fadeInUp" data-wow-delay=".4s">
                     <h2 class="section-title"><i class="flaticon-graduation-cap"></i> My Education</h2>
                  </div>
                  <div class="resume-widget">
                     <div class="resume-item wow fadeInRight" data-wow-delay=".5s">
                        <div class="time">2021 - 2023</div>
                        <h3 class="resume-title">ADP (Computer Science)</h3>
                        <div class="institute">University of Central Punjab</div>
                     </div>
                     <div class="resume-item wow fadeInRight" data-wow-delay=".6s">
                        <div class="time">2023 - Present</div>
                        <h3 class="resume-title">BS (Computer Science)</h3>
                        <div class="institute">University NCBA&E</div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- RESUME SECTION END -->


      <!-- SKILLS SECTION START -->
      <section class="skills-section" id="skills-section">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="section-header text-center">
                     <h2 class="section-title wow fadeInUp" data-wow-delay=".3s">My Skills</h2>
                     <p class="wow fadeInUp" data-wow-delay=".4s">
                        I specialize in building dynamic and responsive websites and web applications that provide high user satisfaction.
                     </p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <div class="skills-widget d-flex flex-wrap justify-content-center align-items-center">
                     <!-- HTML Skill -->
                     <div class="skill-item wow fadeInUp" data-wow-delay=".3s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/skills-1.svg" alt="HTML Icon" />
                           </div>
                           <div class="number">92%</div>
                        </div>
                        <p>HTML</p>
                     </div>
                     <!-- CSS3 Skill -->
                     <div class="skill-item wow fadeInUp" data-wow-delay=".4s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/skills-2.svg" alt="CSS3 Icon" />
                           </div>
                           <div class="number">80%</div>
                        </div>
                        <p>CSS3</p>
                     </div>
                     <!-- Javascript Skill -->
                     <div class="skill-item wow fadeInUp" data-wow-delay=".5s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/skills-3.svg" alt="Javascript Icon" />
                           </div>
                           <div class="number">85%</div>
                        </div>
                        <p>Javascript</p>
                     </div>
                     <!-- Webflow Skill -->
                     <div class="skill-item wow fadeInUp" data-wow-delay=".6s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/webflow-1.svg" alt="Webflow Icon" />
                           </div>
                           <div class="number">99%</div>
                        </div>
                        <p>Webflow</p>
                     </div>
                     <!-- ReactJS Skill -->
                     <div class="skill-item wow fadeInUp" data-wow-delay=".7s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/react.svg" alt="ReactJS Icon" />
                           </div>
                           <div class="number">89%</div>
                        </div>
                        <p>ReactJS</p>
                     </div>
                     <!-- Framer Skill -->
                     <div class="skill-item wow fadeInUp" data-wow-delay=".8s">
                        <div class="skill-inner">
                           <div class="icon-box">
                              <img src="assets/img/icons/framer-1.svg" alt="Framer Icon" />
                           </div>
                           <div class="number">93%</div>
                        </div>
                        <p>Framer</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- SKILLS SECTION END -->


      <!-- TESTIMONIAL SECTION START -->
      <section class="testimonial-section" id="testimonials-section">
         <div class="container">
            <div class="row">
               <div class="col-lg-5">
                  <div class="section-header">
                     <h2 class="section-title wow fadeInLeft" data-wow-delay=".3s">My Client's Stories</h2>
                     <p class="wow fadeInLeft" data-wow-delay=".4s">Empowering people on a new digital journey with my
                        super services</p>
                  </div>
               </div>
               <div class="col-lg-7 col-xl-6 offset-xl-1">
                  <div class="testimonials-widget wow fadeInRight" data-wow-delay=".5s">
                     <div class="owl-carousel testimonial-carousel">
                        <!-- TESTIMONIAL ITEM 1 -->
                        <div class="testimonial-item">
                           <div class="top-area d-flex flex-wrap justify-content-between">
                              <div class="logo-box">
                                 <img src="assets/img/testimonials/logo/1.png" alt="Client Logo 1" />
                              </div>
                              <div class="image-box">
                                 <img src="assets/img/testimonials/user/1.jpg" alt="Client 1" />
                              </div>
                           </div>
                           <div class="icon-box">
                              <!-- SVG Icons here -->
                           </div>
                           <p class="quote">“Taylor is a professional Designer; he really helped my business by providing
                              value to my business."</p>
                           <h4 class="name">Brandon Fraser</h4>
                           <span class="designation">Senior Software Dev, Cosmic Sport</span>
                        </div>

                        <!-- TESTIMONIAL ITEM 2 -->
                        <div class="testimonial-item">
                           <div class="top-area d-flex flex-wrap justify-content-between">
                              <div class="logo-box">
                                 <img src="assets/img/testimonials/logo/2.png" alt="Client Logo 2" />
                              </div>
                              <div class="image-box">
                                 <img src="assets/img/testimonials/user/2.jpg" alt="Client 2" />
                              </div>
                           </div>
                           <div class="icon-box">
                              <!-- SVG Icons here -->
                           </div>
                           <p class="quote">“Taylor is a professional Designer; he really helped my business by providing
                              value to my business."</p>
                           <h4 class="name">Tim Bailey</h4>
                           <span class="designation">SEO Specialist, Theme Junction</span>
                        </div>

                        <!-- TESTIMONIAL ITEM 3 -->
                        <div class="testimonial-item">
                           <div class="top-area d-flex flex-wrap justify-content-between">
                              <div class="logo-box">
                                 <img src="assets/img/testimonials/logo/1.png" alt="Client Logo 1" />
                              </div>
                              <div class="image-box">
                                 <img src="assets/img/testimonials/user/1.jpg" alt="Client 1" />
                              </div>
                           </div>
                           <div class="icon-box">
                              <!-- SVG Icons here -->
                           </div>
                           <p class="quote">“Taylor is a professional Designer; he really helped my business by providing
                              value to my business."</p>
                           <h4 class="name">Brandon Fraser</h4>
                           <span class="designation">Senior Software Dev, Cosmic Sport</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- TESTIMONIAL SECTION END -->


      <!-- CONTACT SECTION START -->
      <section class="contact-section" id="contact-section">
         <div class="container">
            <div class="row">
               <!-- Contact Form Section -->
               <div class="col-lg-6 col-md-7 order-2 order-md-1">
                  <div class="contact-form-box wow fadeInLeft" data-wow-delay=".3s">
                     <div class="section-header">
                        <h2 class="section-title">Let’s work together!</h2>
                        <p>I design and code beautifully simple things and I love what I do. Just simple like that!</p>
                     </div>

                     <!-- Form Section -->
                     <div class="tj-contact-form">
                        <form id="contact-form">
                           <div class="row gx-3">
                              <div class="col-sm-6">
                                 <div class="form_group">
                                    <input type="text" name="conName" id="conName" placeholder="First name" required />
                                 </div>
                              </div>
                              <div class="col-sm-6">
                                 <div class="form_group">
                                    <input type="text" name="conLName" id="conLName" placeholder="Last name" required />
                                 </div>
                              </div>
                              <div class="col-sm-6">
                                 <div class="form_group">
                                    <input type="email" name="conEmail" id="conEmail" placeholder="Email address" required />
                                 </div>
                              </div>
                              <div class="col-sm-6">
                                 <div class="form_group">
                                    <input type="tel" name="conPhone" id="conPhone" placeholder="Phone number" required />
                                 </div>
                              </div>
                              <div class="col-12">
                                 <div class="form_group">
                                    <select name="conService" id="conService" class="tj-nice-select" required>
                                       <option value="" selected disabled>Choose Service</option>
                                       <option value="branding">Branding Design</option>
                                       <option value="web">Web Design</option>
                                       <option value="uxui">UI/UX Design</option>
                                       <option value="app">App Design</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-12">
                                 <div class="form_group">
                                    <textarea name="conMessage" id="conMessage" placeholder="Message" required></textarea>
                                 </div>
                              </div>
                              <div class="col-12">
                                 <div class="form_btn">
                                    <button type="submit" class="btn tj-btn-primary">Send Message</button>
                                 </div>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>

               <!-- Contact Info Section -->
               <div class="col-lg-5 offset-lg-1 col-md-5 d-flex flex-wrap align-items-center order-1 order-md-2">
                  <div class="contact-info-list">
                     <ul class="ul-reset">
                        <li class="d-flex flex-wrap align-items-center position-relative wow fadeInRight" data-wow-delay=".4s">
                           <div class="icon-box">
                              <i class="flaticon-phone-call"></i>
                           </div>
                           <div class="text-box">
                              <p>Phone</p>
                              <a href="tel:0123456789">+01 123 654 8096</a>
                           </div>
                        </li>
                        <li class="d-flex flex-wrap align-items-center position-relative wow fadeInRight" data-wow-delay=".5s">
                           <div class="icon-box">
                              <i class="flaticon-mail-inbox-app"></i>
                           </div>
                           <div class="text-box">
                              <p>Email</p>
                              <a href="mailto:gerolddesign@mail.com">gerolddesign@mail.com</a>
                           </div>
                        </li>
                        <li class="d-flex flex-wrap align-items-center position-relative wow fadeInRight" data-wow-delay=".6s">
                           <div class="icon-box">
                              <i class="flaticon-location"></i>
                           </div>
                           <div class="text-box">
                              <p>Address</p>
                              <a href="#">Warne Park Street Pine, <br />FL 33157, New York</a>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- CONTACT SECTION END -->


      <!-- BEGIN: Contact Form Success Modal Message -->
      <div class="modal contact_modal" id="message_sent" tabindex="-1">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-header">
                  <span class="modal-title"><strong>Message Sent Successfully</strong></span>
                  <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><i
                        class="fas fa-times"></i></button>
               </div>
               <div class="modal-body">
                  <p>Thank you for contacting us. We will get back to you shortly.<br />Have a great day!</p>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn" data-bs-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
      <!-- END: Contact Form Success Modal Message -->

      <!-- BEGIN: Contact Form Fail Modal Message -->
      <div class="modal contact_modal failed" id="message_fail" tabindex="-1">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-header">
                  <span class="modal-title"><strong>Error</strong></span>
                  <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><i
                        class="fas fa-times"></i></button>
               </div>
               <div class="modal-body">
                  <p>Oops! Something went wrong, please try again.</p>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn" data-bs-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
      <!-- END: Contact Form Fail Modal Message End -->
   </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\portfolio\resources\views/index.blade.php ENDPATH**/ ?>